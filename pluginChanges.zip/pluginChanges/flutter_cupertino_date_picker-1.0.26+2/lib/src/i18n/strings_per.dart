part of 'date_picker_i18n.dart';

/// Hungarian
class _StringsPas extends _StringsI18n {
  const _StringsPas();

  @override
  String getCancelText() {
    return 'لغوه';
  }

  @override
  String getDoneText() {
    return 'انجام شده';
  }

  @override
  List<String> getMonths() {
    return [
      "ژانویه",
      "فوریه",
      "مارس",
      "آپریل",
      "مه",
      "ژوئن",
      "جولای",
      "اوت",
      "سپتامبر",
      "اکتبر",
      "نوامبر",
      "دسامبر"
    ];
  }

  @override
  List<String> getMonthsShort() {
    return [
      "Jan.",
      "Feb.",
      "Mar.",
      "Apr.",
      "May",
      "Jun",
      "Jul.",
      "Aug.",
      "Sep.",
      "Oct.",
      "Nov.",
      "Dec.",
    ];
  }
  
  @override
  List<String> getWeeksFull() {
    return [
      "Hétfő",
      "Kedd",
      "Szerda",
      "Csütörtök",
      "Péntek",
      "Szombat",
      "Vasárnap",
    ];
  }

  @override
  List<String> getWeeksShort() {
    return [
      "H",
      "K",
      "Sze",
      "Cs",
      "P",
      "Szo",
      "V",
    ];
  }
}
