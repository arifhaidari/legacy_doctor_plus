part of 'date_picker_i18n.dart';

/// Hungarian
class _StringsPer extends _StringsI18n {
  const _StringsPer();

  @override
  String getCancelText() {
    return 'لغوه کول';
  }

  @override
  String getDoneText() {
    return 'وشو';
  }

  @override
  List<String> getMonths() {
    return [
      "جنوري",
      "فبروري",
      "مارچ",
      "اپریل",
      "می",
      "جون",
      "جولای",
      "اګست",
      "سپتمبر",
      "اکتوبر",
      "نومبر",
      "دسمبر"
    ];
  }

    @override
  List<String> getMonthsShort() {
    return [
      "Jan.",
      "Feb.",
      "Mar.",
      "Apr.",
      "May",
      "Jun",
      "Jul.",
      "Aug.",
      "Sep.",
      "Oct.",
      "Nov.",
      "Dec.",
    ];
  }
  

  @override
  List<String> getWeeksFull() {
    return [
      "Hétfő",
      "Kedd",
      "Szerda",
      "Csütörtök",
      "Péntek",
      "Szombat",
      "Vasárnap",
    ];
  }

  @override
  List<String> getWeeksShort() {
    return [
      "H",
      "K",
      "Sze",
      "Cs",
      "P",
      "Szo",
      "V",
    ];
  }
}
